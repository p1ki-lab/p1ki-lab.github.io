import io
import unittest

from debugger import Debugger
from html_markup import remove_html_markup
from html_markup_before import remove_html_markup as before_fix
from verify_html_fix import CASES


class HtmlMarkupTests(unittest.TestCase):
    def test_quote_regressions(self):
        for text, expected in CASES:
            with self.subTest(text=text):
                self.assertEqual(remove_html_markup(text), expected)

    def test_original_defect_is_reproduced(self):
        self.assertEqual(before_fix('"<b>foo</b>"'), '<b>foo</b>')
        self.assertEqual(before_fix('<b>"foo"</b>'), 'foo')

    def test_corrected_function_under_debugger(self):
        output = io.StringIO()
        with Debugger(commands=['watch quote', 'continue', 'continue', 'continue'], file=output):
            result = remove_html_markup('"<b>foo</b>"')
        self.assertEqual(result, '"foo"')
        self.assertIn('watch quote: <undefined> -> False', output.getvalue())
        self.assertNotIn('False -> True', output.getvalue())


if __name__ == '__main__':
    unittest.main()
