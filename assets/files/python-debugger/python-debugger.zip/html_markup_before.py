def remove_html_markup(text):
    tag = False
    quote = False
    out = ''
    for character in text:
        if character == '<' and not quote:
            tag = True
        elif character == '>' and not quote:
            tag = False
        elif character == '"' or character == "'" and tag:
            quote = not quote
        elif not tag:
            out += character
    return out
