import io
import sys

from debugger import Debugger
from test_debugger import changes


commands = [
    'unknown',
    'exceptions invalid',
    'print missing',
    'until nope',
    'watch 2 +',
    'up',
    'down',
    'break -1',
    'continue',
]
output = io.StringIO()
previous = sys.gettrace()
with Debugger(commands=commands, file=output):
    result = changes()

transcript = output.getvalue()
print(transcript, end='')
error_count = transcript.count('ERROR')
restored = sys.gettrace() is previous
print('Error messages:', error_count)
print('Returned result:', result)
print('Trace restored:', restored)
assert error_count == 8
assert result == 2
assert restored
print('CHECK: PASS')
