import inspect
import io
import sys
import unittest

from debugger import Debugger
from demo import calculate


def inner(number):
    doubled = number * 2
    return doubled


def outer():
    amount = 7
    result = inner(amount)
    return result


def changes():
    total = 0
    total += 2
    return total


def failing():
    return 1 / 0


class DebuggerTests(unittest.TestCase):
    def run_session(self, function, commands):
        output = io.StringIO()
        previous = sys.gettrace()
        with Debugger(commands=commands, file=output):
            result = function()
        self.assertIs(sys.gettrace(), previous)
        return result, output.getvalue()

    def test_step_print_list_help_and_next(self):
        result, output = self.run_session(outer, [
            'help', 'step', 'next', 'print amount', 'list', 'next', 'print result', 'continue'
        ])
        self.assertEqual(result, 14)
        self.assertIn('print: print [EXPR]', output)
        self.assertIn('\n7\n', output)
        self.assertIn('\n14\n', output)
        self.assertIn('result = inner(amount)', output)
        self.assertNotIn('STOP call inner', output)

    def test_function_breakpoint_stack_and_finish(self):
        result, output = self.run_session(outer, [
            'break inner', 'continue', 'where', 'up', 'print amount', 'down',
            'print number', 'delete inner', 'finish', 'print doubled', 'continue'
        ])
        self.assertEqual(result, 14)
        self.assertIn('function breakpoint', output)
        self.assertIn('#1 outer', output)
        self.assertIn('STOP return inner', output)
        self.assertIn('value=14', output)

    def test_line_breakpoint_delete_and_until(self):
        line = inspect.getsourcelines(changes)[1] + 2
        result, output = self.run_session(changes, [
            f'break {line}', 'continue', 'print total', f'delete {line}',
            'until', 'print total', 'continue'
        ])
        self.assertEqual(result, 2)
        self.assertIn('line breakpoint', output)
        self.assertIn('\n0\n', output)
        self.assertIn('\n2\n', output)

    def test_watch_undefined_change_and_delete(self):
        result, output = self.run_session(changes, [
            'watch total', 'continue', 'continue', 'print total', 'delete total', 'continue'
        ])
        self.assertEqual(result, 2)
        self.assertIn('watch total: <undefined> -> 0', output)
        self.assertIn('watch total: 0 -> 2', output)

    def test_exceptions_on_and_off(self):
        result, enabled = self.run_session(lambda: calculate([10]), [
            'exceptions on', 'continue', 'where', 'print price', 'continue'
        ])
        self.assertEqual(result, 8)
        self.assertIn('STOP exception calculate', enabled)
        self.assertIn('ZeroDivisionError', enabled)
        _, disabled = self.run_session(lambda: calculate([10]), ['exceptions off', 'continue'])
        self.assertNotIn('STOP exception', disabled)

    def test_invalid_commands_do_not_resume(self):
        result, output = self.run_session(changes, [
            'unknown', 'exceptions invalid', 'print missing', 'until nope',
            'watch 2 +', 'up', 'down', 'break -1', 'continue'
        ])
        self.assertEqual(result, 2)
        self.assertEqual(output.count('ERROR'), 8)

    def test_quit_and_eof(self):
        self.assertEqual(self.run_session(changes, ['quit'])[0], 2)
        self.assertEqual(self.run_session(changes, [])[0], 2)

    def test_explicit_until_and_target_return(self):
        line = inspect.getsourcelines(outer)[1] + 1
        result, output = self.run_session(outer, [f'until {line}', 'print amount', 'continue'])
        self.assertEqual(result, 14)
        self.assertIn('\n7\n', output)
        result, output = self.run_session(outer, [
            'break inner', 'continue', 'finish', 'next', 'print result', 'continue'
        ])
        self.assertEqual(result, 14)
        self.assertIn('\n14\n', output)

    def test_delete_function_breakpoint(self):
        _, output = self.run_session(outer, ['break inner', 'delete inner', 'continue'])
        self.assertNotIn('STOP call inner', output)

    def test_unhandled_exception_restores_trace(self):
        previous = sys.gettrace()
        with self.assertRaises(ZeroDivisionError):
            with Debugger(commands=['exceptions on', 'continue', 'continue'], file=io.StringIO()):
                failing()
        self.assertIs(sys.gettrace(), previous)


if __name__ == '__main__':
    unittest.main()
