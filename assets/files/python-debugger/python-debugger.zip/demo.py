from debugger import Debugger


def discounted(price):
    return price * 0.8


def calculate(prices):
    total = 0
    for price in prices:
        total += discounted(price)
    try:
        total / 0
    except ZeroDivisionError:
        pass
    return total


if __name__ == '__main__':
    with Debugger():
        result = calculate([1000, 2000, 3000])
    print('Result:', result)
