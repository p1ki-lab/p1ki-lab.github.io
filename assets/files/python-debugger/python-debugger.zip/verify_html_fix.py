import inspect
import sys

from debugger import Debugger
from html_markup import remove_html_markup
from html_markup_before import remove_html_markup as before_fix


CASES = [
    ('<b>foo</b>', 'foo'),
    ('<b>"foo"</b>', '"foo"'),
    ('"<b>foo</b>"', '"foo"'),
    ('"foo"', '"foo"'),
    ("'foo'", "'foo'"),
    ('<b id="bar">foo</b>', 'foo'),
    ('<input type="text" value="<your name>">', ''),
]


def main():
    print('HTML quote bug: real before/after execution')
    print('Python:', sys.version.split()[0])
    print('BEFORE fixture:', inspect.getfile(before_fix))
    print('AFTER module:  ', inspect.getfile(remove_html_markup))
    print('Fix: A or (B and tag) -> (A or B) and tag')
    print()
    failures = 0
    for text, expected in CASES:
        before = before_fix(text)
        after = remove_html_markup(text)
        failures += before != expected
        print('INPUT:   ', repr(text))
        print('EXPECTED:', repr(expected))
        print('BEFORE:  ', repr(before), '[PASS]' if before == expected else '[FAIL]')
        print('AFTER:   ', repr(after), '[PASS]' if after == expected else '[FAIL]')
        assert after == expected, (text, after, expected)
    print()
    print(f'BEFORE: {failures}/{len(CASES)} failed; AFTER: {len(CASES)}/{len(CASES)} passed')
    text = '"<b>foo</b>"'
    print('Run corrected function under our Debugger:')
    with Debugger(commands=['continue']):
        result = remove_html_markup(text)
    assert result == '"foo"'
    print('DEBUGGER RESULT:', repr(result))
    print('CHECK: PASS')


if __name__ == '__main__':
    main()
